import styled from "styled-components"
import { MdOutlineAddToHomeScreen } from "react-icons/md";
import Header from "./static/Header";
import Home from "./pages/Home";
import Footer from "./static/Footer";
const App = () => {
  return(
    <div>
      <Header />
      < Home />
      <Footer />
    </div>
  )
}


export default App

const Container = styled.div`
  background-color: red;
  font-size: 30px;
  color: pink;
`