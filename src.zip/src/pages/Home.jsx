const Home = () => {
    return(
        <div>
            <h1>this is the home</h1>
        </div>
    )
}

export default Home