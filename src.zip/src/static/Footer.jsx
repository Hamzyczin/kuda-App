const Footer = () => {
    return(
        <div>
            <h1>this is the Footer</h1>
        </div>
    )
}

export default Footer