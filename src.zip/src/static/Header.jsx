import { MdArrowDropDown } from "react-icons/md" 
const Header = () => {
    return(
        <Container>
            <LogoNav>
                <Logo>
                    <img src="" alt="" />
                </Logo>
                <Navigation>
                    <nav>
                        <span>Personal</span>
                        <MdArrowDropDown size= {20}/>
                    </nav>
                    <nav>
                        <span>Business</span>
                        <MdArrowDropDown size= {20}/>
                    </nav>
                    <nav>
                        <span>Company</span>
                        <MdArrowDropDown size= {20}/>
                    </nav>
                    <nav>
                        <span>Help</span>
                        <MdArrowDropDown size= {20}/>
                    </nav>
                </Navigation>
            </LogoNav>
            <Button>
                <SignBtn> Sign In</SignBtn>
                <JoinBtn>Join Kuda</JoinBtn>
            </Button>
        </Container>
    )
}

export default Header

const Container = styled.div``
const LogoNav = styled.div``
const Logo = styled.div``
const Navigation = styled.div``
const Button = styled.div``

